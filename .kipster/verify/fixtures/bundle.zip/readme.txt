Fixture archive.
